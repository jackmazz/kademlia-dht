/*
Copyright 2021 Ethan Blanton <eblanton@buffalo.edu>

This file is part of a CSE 486/586 project from the University at
Buffalo.  Distribution of this file or its associated repository
requires the written permission of Ethan Blanton.  Sharing this file
may be a violation of academic integrity, please consult the course
policies for more package.
*/

package tests

/*
import (
	"testing"

	"cse586.kdht/api/kdht"
	"cse586.kdht/impl"
)

func TestCreateEmptyTableK2(t *testing.T) {
	n := &kdht.NodeInfo{Id: leftCenter}
	kt, err := impl.NewRoutingTable(n, 2)
	if err != nil {
		t.Fatal(err)
	}

	if kt.Buckets() != 1 {
		t.Errorf("Empty routing table had too many buckets (%d)", kt.Buckets())
	}
	if kt.K() != 2 {
		t.Errorf("Empty table with k = 2 had k = %d\n", kt.K())
	}
}
*/
